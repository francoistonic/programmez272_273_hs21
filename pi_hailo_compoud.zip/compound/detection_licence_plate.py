import degirum as dg, degirum_tools
from picamera2 import Picamera2
import cv2
import os
import time
from pynput import keyboard

class FPS:
    def __init__(self, block_size=300):
        self.block_size = block_size
        self.block_frame_count = 0
        self.block_start_time = time.time()
    
    def update_fps(self):
        # Calculation of the FPS in block
        elapsed = time.time() - self.block_start_time
        fps = self.block_frame_count / elapsed if elapsed > 0 else 0.0
        return fps
    
    def update_inference(self, model):
        # Stats for inférence
        stats = model.time_stats()
        inference = stats.get("CoreInferenceDuration_ms", None)

        if inference is not None:
            avg_inf_latency = inference.avg
            avg_inf_fps = 1000.0 / avg_inf_latency if avg_inf_latency > 0 else 0.0
        else:
            print("No inference metric available.")
            avg_inf_latency, avg_inf_fps = 0.0, 0.0

        return avg_inf_latency, avg_inf_fps
    
    def should_reset(self):
        return self.block_frame_count >= self.block_size
    
    def reset_block(self, model1, model2):
        print(f"\n--- Block of {self.block_size} frames completed. Resetting metrics. ---")
        self.block_frame_count = 0
        self.block_start_time = time.time()
        model1.reset_time_stats()
        model2.reset_time_stats()

def source(camera: Picamera2):
    while True:
        frame = camera.capture_array()
        yield frame

def on_press_event(key):
    global stop_flag
    if (hasattr(key, 'char') and key.char == 'q'):
        stop_flag = True
        return False

stop_flag = False

listener = keyboard.Listener(on_press=on_press_event)
listener.start()

camera = Picamera2()
camera.configure(camera.create_video_configuration(main={"format": "RGB888"}))
camera.start()

# Allow camera to warm up
time.sleep(1)

frame = camera.capture_array()
height, width, _ = frame.shape

# Initialize VideoWriter
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
out = cv2.VideoWriter('video.mp4', fourcc, 30.0, (width, height))

current_dir = os.path.dirname(os.path.abspath(__file__))
models_dir = os.path.join(current_dir, "models") 
lp_det_model_name = "yolov8n_relu6_global_lp_det--640x640_quant_hailort_multidevice_1"
lp_ocr_model_name = "yolov8s_relu6_lp_ocr_7ch--256x128_quant_hailort_multidevice_1"
host_adress = "@local"

lp_det_model = dg.load_model(
    model_name=lp_det_model_name,
    inference_host_address=host_adress,
    zoo_url=models_dir,
    measure_time=True
)

lp_ocr_model = dg.load_model(
    model_name=lp_ocr_model_name,
    inference_host_address=host_adress,
    zoo_url=models_dir,
    measure_time=True
)

fpsHandler = FPS()

with lp_det_model, lp_ocr_model:
    crop_model = degirum_tools.CroppingAndClassifyingCompoundModel(
        lp_det_model,
        lp_ocr_model,
    )

    for result in crop_model.predict_batch(source(camera)):
        annotated_frame = result.image_overlay
        fpsHandler.block_frame_count += 1

        avg_det_inf_latency, avg_det_inf_fps = fpsHandler.update_inference(lp_det_model)

        avg_ocr_inf_latency, avg_ocr_inf_fps = fpsHandler.update_inference(lp_ocr_model)

        out.write(annotated_frame)

        fps = fpsHandler.update_fps()

        print(f"Average Detection Inference : {avg_det_inf_latency:.2f}ms, {avg_det_inf_fps:.2f} FPS")
        print(f"Average OCR Inference : {avg_ocr_inf_latency:.2f}ms, {avg_ocr_inf_fps:.2f} FPS")
        print(f"Overall FPS: {fps:.2f} FPS")

        if fpsHandler.should_reset():
            fpsHandler.reset_block(lp_det_model, lp_ocr_model)
        
        cv2.imshow("Camera", annotated_frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        if stop_flag:
            break

out.release()
camera.stop()
print(" Resources released")