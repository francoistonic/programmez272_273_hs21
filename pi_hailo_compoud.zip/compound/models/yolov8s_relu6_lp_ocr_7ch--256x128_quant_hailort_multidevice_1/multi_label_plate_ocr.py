import numpy as np
import json

# Post-processor class, must have fixed name 'PostProcessor'
class PostProcessor:
    def __init__(self, json_config):
        """
        Initialize the post-processor with configuration settings.
        Original logic: parse JSON config and extract parameters.
        """
        # Parse the JSON configuration
        cfg = json.loads(json_config)
        pp = cfg["POST_PROCESS"][0]
        pre = cfg["PRE_PROCESS"][0]

        # Configuration parameters (original JSON parsing)
        self._num_classes = int(pp.get("OutputNumClasses", 1))
        self._num_labels = int(pp.get("OutputNumLabels", 1))
        self._label_json_path = pp["LabelsPath"]
        self._top_k = int(pp.get("OutputTopK", 3))
        self._input_height = int(pre.get("InputH", 0))
        self._input_width = int(pre.get("InputW", 0))
        self._softmax_en = pp.get("OutputSoftmaxEn", False)

        # Load label dictionary (original label lookup)
        with open(self._label_json_path, "r") as f:
            self._label_dictionary = json.load(f)
        if self._label_dictionary.get("class_names"):
            self._class_names = list(self._label_dictionary["class_names"].values())
        else:
            self._class_names = list(self._label_dictionary.values())

        if self._label_dictionary.get("label_names"):
            self._label_names = list(self._label_dictionary["label_names"].values())
        else:
            self._label_names = [f"label_{i}" for i in range(self._num_labels)]

    def multilabelclassify_postprocessing(self, tensor_list, details_list=None):
        """
        Post-process multi-label classification outputs.

        Parameters:git 
            tensor_list (list): List of NumPy arrays from the model output, each shape [B, nl, nc].
            details_list (list): List of dicts containing 'quantization' info for each tensor.
        Returns:
            List[dict]: Each dict has keys 'group', 'class_id', 'score', 'label'.
        """
        for idx, tensor in enumerate(tensor_list):
            qp = details_list[idx]["quantization_parameters"]
            zero_pt = float(qp["zero_points"][0])
            scale = float(qp["scales"][0])
            tensor = (tensor.astype(np.float32) - zero_pt) * scale
            tensor_list[idx] = tensor

        probs = tensor_list[0]

        # normalized_results [prob, indeces] of the topk
        normalized_results = self.topk_joint_plate_probabilities_optimized(probs[0], k=10)

        results = []
        # enumarete for 5 positions
        for i in range(self._top_k):
            prob, indices = normalized_results[i]
            results.append({
                "score": float(prob),
                "label": "".join([self._class_names[idx] for idx in indices])
            })

        return results

    def topk_joint_plate_probabilities_optimized(self, probs, k=10):
        """
        Approximates the top-k most probable joint output sequences ("plates") using a greedy ratio-based strategy.

        Args:
            probs (np.ndarray): Softmaxed probabilities of shape (7, 37), one row per output position.
            k (int): Number of top plate sequences to return.

        Returns:
            List of tuples (normalized_joint_probability, plate_indices) where:
                - normalized_joint_probability: float in [0, 1]
                - plate_indices: list of 7 integers (original class indices)
        """
        # Ensure probs is a 2D array with shape (..., num_classes)
        probs = probs.reshape(-1, self._num_classes)
        if self._softmax_en:
            # Apply softmax if enabled
            probs = np.exp(probs - np.max(probs, axis=1, keepdims=True))
            probs /= np.sum(probs, axis=1, keepdims=True)
        
        num_positions, num_classes = probs.shape
        # assert num_positions == 7, "Expected 7 output positions"

        # Step 1: Sort probabilities and record sorted indices
        sorted_indices = np.argsort(-probs, axis=1)  # descending order
        sorted_probs = np.take_along_axis(probs, sorted_indices, axis=1)

        # Step 2: Initialize plate, ratios, and current probability
        plate = [0] * num_positions
        current_prob = np.prod([sorted_probs[i, 0] for i in range(num_positions)])
        ratios = [
            (sorted_probs[i, 1] / sorted_probs[i, 0]) if num_classes > 1 else np.inf
            for i in range(num_positions)
        ]

        results = [(current_prob, plate.copy())]
        visited = {tuple(plate)}

        for _ in range(k - 1):
            # Select dimension with minimal ratio (least damaging change)
            j = np.argmax(ratios)

            # Advance that index
            plate[j] += 1

            # Recompute joint probability using ratio
            current_prob *= ratios[j]
            results.append((current_prob, plate.copy()))
            visited.add(tuple(plate))

            # Update the ratio for position j
            if plate[j] + 1 < num_classes:
                next_prob = sorted_probs[j, plate[j] + 1]
                curr_prob = sorted_probs[j, plate[j]]
                ratios[j] = next_prob / curr_prob
            else:
                ratios[j] = -np.inf  # No further steps for this dimension

        # Normalize results
        total = sum(p for p, _ in results)
        normalized_results = [
            (p / total, [sorted_indices[i, idx] for i, idx in enumerate(plate)])
            for p, plate in results
        ]

        return normalized_results


    def forward(self, tensor_list, details_list=None):
        """
        Forward pass that invokes the multi-label classification post-processing.
        """
        return self.multilabelclassify_postprocessing(tensor_list, details_list)

    