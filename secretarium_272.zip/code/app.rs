#[allow(warnings)]
mod bindings;

use bindings::klave::sdk::sdk;

struct Component;

impl Guest for Component {
    fn greet_user(user: String) {
        let Ok(city) = sdk::read_ledger("user_city", &user) else {
            sdk::notify(&format!("Failed to read from ledger: '{user}'"));
            return;
        };

        let msg = if city.is_empty() {
            format!("The key '{user}' was not found in user_city")
        } else {
            match String::from_utf8(city) {
                Ok(city_name) => format!("Hello {user} from city {city_name}"),
                Err(_) => {
                    sdk::notify(&format!("Invalid UTF-8 data for user '{user}'"));
                    return;
                }
            }
        };

        sdk::notify(&msg);
    }
}

bindings::export! (Component with_types_in bindings);
