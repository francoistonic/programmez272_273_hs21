import degirum as dg
from picamera2 import Picamera2
import cv2
import os
import time

class FPS:
    def __init__(self, block_size=300):
        self.block_size = block_size
        self.block_frame_count = 0
        self.block_start_time = time.time()
    
    def update_fps(self):
        # Calculation of the FPS in block
        elapsed = time.time() - self.block_start_time
        fps = self.block_frame_count / elapsed if elapsed > 0 else 0.0
        return fps
    
    def update_inference(self, model):
        # Stats for inférence
        stats = model.time_stats()

        avg_inf_latency = stats["CoreInferenceDuration_ms"].avg
        avg_inf_fps = 1000.0 / avg_inf_latency if avg_inf_latency > 0 else 0.0

        return avg_inf_latency, avg_inf_fps
    
    def should_reset(self):
        return self.block_frame_count >= self.block_size
    
    def reset_block(self, model):
        print(f"\n--- Block of {self.block_size} frames completed. Resetting metrics. ---")
        self.block_frame_count = 0
        self.block_start_time = time.time()
        model.reset_time_stats()

def source(camera: Picamera2):
    while True:
        frame = camera.capture_array()
        yield frame  

# Initialize the camera
camera = Picamera2()
camera.configure(camera.create_video_configuration(main={"format": "RGB888"}))
camera.start()

# Allow camera to warm up
time.sleep(1)

frame = camera.capture_array()
height, width, _ = frame.shape

# Initialize VideoWriter
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
out = cv2.VideoWriter('video.mp4', fourcc, 30.0, (width, height))

model_name = "yolov8n_coco--640x640_quant_hailort_multidevice_1"
current_dir = os.path.dirname(os.path.abspath(__file__))
models_dir = os.path.join(current_dir, "models") 
host_adress = "@local"

model = dg.load_model(
    model_name = model_name, 
    inference_host_address = host_adress, 
    zoo_url = models_dir,
    overlay_show_probabilities=True,
    output_confidence_threshold=0.5,
    measure_time=True
)

fpsHandler = FPS() 

try:
    for result in model.predict_batch(source(camera)):
        annotated_frame = result.image_overlay
        fpsHandler.block_frame_count += 1

        avg_inf_latency, avg_inf_fps = fpsHandler.update_inference(model)

        out.write(annotated_frame)

        fps = fpsHandler.update_fps()

        print(f"Average Inference : {avg_inf_latency:.2f}ms, {avg_inf_fps:.2f} FPS")
        print(f"Overall FPS: {fps:.2f} FPS")
        
        if fpsHandler.should_reset():
            fpsHandler.reset_block(model)
        
except KeyboardInterrupt:
    print(" Stopping gracefully...")

finally:
    out.release()
    camera.stop()

# Average Inference : 14.71ms, 67.99 FPS
# Overall FPS: 25.48 FPS
# Average Inference : 14.69ms, 68.09 FPS
# Overall FPS: 25.53 FPS
# Average Inference : 14.69ms, 68.08 FPS
# Overall FPS: 25.54 FPS
# Average Inference : 14.66ms, 68.23 FPS
# Overall FPS: 25.61 FPS
    
# Average Inference : 15.30ms, 65.36 FPS
# Overall FPS: 29.77 FPS
# Average Inference : 15.30ms, 65.37 FPS
# Overall FPS: 29.77 FPS
# Average Inference : 15.30ms, 65.37 FPS
# Overall FPS: 29.78 FPS
# Average Inference : 15.31ms, 65.33 FPS
# Overall FPS: 29.77 FPS
    
