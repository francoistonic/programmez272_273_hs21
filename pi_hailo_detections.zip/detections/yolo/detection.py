from ultralytics import YOLO
from picamera2 import Picamera2
import time
import cv2

class FPS():
    def __init__(self, block_size=300):
        self.block_size = block_size
        self.block_frame_count = 0
        self.block_start_time = time.time()
        self.total_inference_time = 0
    
    def update_fps(self):
        # Calculation of the FPS in block
        elapsed = time.time() - self.block_start_time
        fps = self.block_frame_count / elapsed if elapsed > 0 else 0.0
        return fps

    def update_inference(self, speed):
        inference_time = speed['inference']
        self.total_inference_time += inference_time

        avg_inf_latency = self.total_inference_time / self.block_frame_count if self.block_frame_count > 0 else 0
        avg_inf_fps = 1000 / avg_inf_latency if avg_inf_latency > 0 else 0

        return avg_inf_latency, avg_inf_fps
    
    def should_reset(self):
        return self.block_frame_count >= self.block_size
    
    def reset_block(self):
        print(f"\n--- Block of {self.block_size} frames completed. Resetting metrics. ---")
        self.block_frame_count = 0
        self.block_start_time = time.time()
        self.total_inference_time = 0


model_name = "./models/yolov8n_ncnn_model_320"

# initialize the camera and grab a reference to the raw camera capture
camera = Picamera2()
camera.configure(camera.create_video_configuration(main={"format": "RGB888"}))
camera.start()

# Allow camera to warm up
time.sleep(1)

frame = camera.capture_array()
height, width, _ = frame.shape

fourcc = cv2.VideoWriter_fourcc(*'mp4v')
out = cv2.VideoWriter('video.mp4', fourcc, 14.0, (width, height))

model = YOLO(model_name)

fpsHandler = FPS() 

try:
    while True:
        frame = camera.capture_array()
        fpsHandler.block_frame_count += 1

        results = model(frame, imgsz=320, conf=0.5, verbose=False)

        # Get frame with boxes
        annotated_frame = results[0].plot()
        
        avg_inf_latency, avg_inf_fps = fpsHandler.update_inference(results[0].speed)

        # Save frame in video
        out.write(annotated_frame)

        fps = fpsHandler.update_fps()

        print(f"Average Inference : {avg_inf_latency:.2f}ms, {avg_inf_fps:.2f} FPS")
        print(f"Overall FPS: {fps:.2f} FPS")
        
        cv2.imshow("Camera", annotated_frame)

        if fpsHandler.should_reset():
            fpsHandler.reset_block()

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

except KeyboardInterrupt:
    print(" Stopping gracefully...")

finally:
    out.release()
    camera.stop()




    
